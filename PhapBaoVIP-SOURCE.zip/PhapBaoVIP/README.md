# PhapBaoVIP 1.0.0 — Pháp bảo tu tiên có VIP (Paper 1.21.x)

## Build
```
mvn clean package
```
File jar nằm ở `target/PhapBaoVIP-1.0.0.jar`, thả vào `plugins/`. Cần Java 21.
(Gói này là source, chưa được biên dịch trong môi trường của mình vì không có JDK/Maven/Paper API.)

## Cơ chế
- **Phẩm cấp**: Hạ → Trung → Thượng → Cực → Tiên Khí (đổi tên/màu/tỉ lệ trong `quality`).
- **Luyện hóa (nhận chủ)**: pháp bảo phải luyện hóa mới dùng được kỹ năng. Mỗi người có giới hạn *bản mệnh pháp bảo* theo VIP.
- **Cấp luyện +0…+10**: tăng công kích và sát thương kỹ năng. Nâng cấp tốn nguyên liệu, có tỉ lệ thành công; VIP cộng tỉ lệ và hoàn nguyên liệu khi thất bại.
- **Linh lực + hồi chiêu**: mỗi kỹ năng tốn linh lực, VIP có thêm linh lực tối đa, hồi nhanh hơn, giảm hồi chiêu.
- **Kỹ năng**: Chuột phải = chiêu 1, **Shift + Chuột phải** = chiêu 2 (Bedrock dùng nút ngồi + chạm giữ).
- **VIP**: 3 bậc theo permission `phapbao.vip.1/2/3`, có pháp bảo VIP riêng (`vip-only: true`) và quà hằng ngày `/pb daily`.
- **Cảnh giới**: nối với plugin tu tiên qua PlaceholderAPI (xem dưới).

## Lệnh
| Lệnh | Tác dụng |
|---|---|
| `/pb` | Mở menu |
| `/pb luyenhoa` / `giaitru` / `nangcap` | Luyện hóa / giải trừ / nâng cấp pháp bảo đang cầm |
| `/pb daily` | Quà VIP hằng ngày |
| `/pb info`, `/pb list` | Xem thông tin, danh mục |
| `/pb give <tên> <id> [cấp]` | Admin: trao pháp bảo (dùng được trong command của boss/crate) |
| `/pb resetslot <tên>` | Admin: đặt lại ô bản mệnh |
| `/pb reload` | Tải lại config |

## Permission
`phapbao.use` (mặc định), `phapbao.admin` (op), `phapbao.vip.1`, `phapbao.vip.2`, `phapbao.vip.3`.
Ví dụ LuckPerms: `/lp user <tên> permission set phapbao.vip.2 true`

## Nối với TuTienPlugin (cảnh giới)
Trong `config.yml`:
```yaml
realm:
  placeholder: "%tutien_realm_level%"   # THAY bằng placeholder thật, phải trả về SỐ
```
Có placeholder này thì: pháp bảo có `min-realm` sẽ bị khóa theo cảnh giới, sát thương kỹ năng tăng theo cảnh giới (`realm-damage-scale`), linh lực tối đa tăng theo cảnh giới (`mana-per-realm`). Để trống thì cảnh giới coi như 0.

## Thêm pháp bảo mới
Chép một khối trong `phapbao:` ở `config.yml`, đổi id/tên/kỹ năng rồi `/pb reload`. 10 loại kỹ năng:
`KIEM_KHI, LOI_PHAP, HOA_CAU, BANG_PHONG, HO_THAN, HOI_XUAN, PHONG_TOC, THIEN_KIEM_TRAN, HUT_LINH, CHAN_AP`.

## Ghi chú
- Hiệu ứng chỉ dùng particle vanilla nên hiển thị được trên cả PC và PE (Geyser). Tên particle sai sẽ tự thay bằng `END_ROD` và báo warning.
- Sát thương đi qua `damage(amount, caster)` nên WorldGuard/plugin bảo vệ vẫn chặn được PvP trong vùng cấm.
- Linh lực và hồi chiêu lưu trong RAM (reset khi restart); số ô bản mệnh và ngày nhận quà lưu ở `data.yml`.

## PhapBaoVIP - nâng cấp

- Damage skill tối thiểu: 100.
- Damage tăng theo phẩm cấp pháp bảo: Hạ 100, Trung 150, Thượng 250, Cực 400, Tiên 1000.
- Cường hóa tối đa +50; mỗi cấp +10% damage skill, nên +50 = x6 damage trước các hệ số khác.
- Engine có thêm 50 loại skill tu tiên mới (type có thể dùng trong `config.yml`).
- Skill cao cấp có animation vòng nhiều tầng và AOE; có thể mở rộng mechanic riêng sau này.
- Giữ nguyên hệ thống luyện hóa, linh lực, VIP, nâng cấp, cảnh giới và 12 pháp bảo cũ.

### 50 skill mới

VAN_KIEM_QUY_TONG, NHAT_KIEM_PHA_THIEN, KIEM_ANH_PHAN_THAN, KIEM_VUC,
KIEM_BO_VO_HINH, THIEN_NGOAI_PHI_TIEN, KIEM_TOA_CAN_KHON, KIEM_Y_BAO_PHAT,
CUU_THIEN_THAN_LOI, LOI_LONG_XUAT_HAI, LOI_DON, LOI_VUC, THIEN_LOI_PHAT_THE,
LOI_THAN_HO_THE, TAM_MUOI_CHAN_HOA, HOA_LIEN_BAO, HOA_LONG_THON_THIEN,
PHAN_THIEN, PHUONG_HOANG_NIET_BAN, HOA_VUC, VAN_LY_BANG_PHONG, BANG_LONG,
HAN_NGUYET_TRAM, TUYET_DOI_BANG_PHONG, BANG_TUONG, BANG_VUC, SINH_TU_LUAN_HOI,
SINH_MENH_CHUYEN_HOAN, TU_VONG_CHI, AM_DUONG_NGHICH_CHUYEN, LUAN_HOI_AN,
HOANG_TUYEN_DAN, XUYEN_KHONG, KHONG_GIAN_TRAM, THUAN_BO, HU_KHONG_LAO,
THOI_GIAN_TINH_CHI, THOI_QUANG_HOI_TU, NHIEM_HON, SOUL_SHATTER,
THAN_THUC_AP_CHE, DOAT_HON, VAN_HON_PHIEN, CHU_THIEN_TINH_DAU_TRAN,
PHONG_THIEN_TOA_DIA, CUU_CUNG_KIEM_TRAN, DIET_THE_DAI_TRAN, CAM_CHE_PHAN_KICH,
DAO_VUC_GIANG_LAM, MOT_BUOC_DAP_THIEN.


## GUI 2.0.1
- `/pb` mở GUI chính 54 ô.
- Kho pháp bảo, thư viện 50+ skill, chi tiết pháp bảo.
- Nút luyện hóa, cường hóa, giải trừ và daily gọi trực tiếp engine hiện có.
- `/pb kho` mở kho/danh mục.
- `/pb skills` mở thư viện skill.
- `/pb info` xem chi tiết món đang cầm.
- Các module thức tỉnh/khí linh/khảm ngọc/đấu giá chưa được giả lập thành chức năng hoạt động; GUI chỉ hiển thị trạng thái để tránh tạo tính năng giả.


## Fixing Java native-memory allocation errors on Windows

1. Close browsers, games, launchers, and other memory-heavy apps.
2. Run `build-low-memory.bat` from this project folder.
3. If Java still reports `There is insufficient memory`, enable/increase Windows virtual memory:
   - Press `Win + R`, enter `sysdm.cpl`, press Enter.
   - Advanced > Performance > Settings > Advanced > Virtual memory > Change.
   - Prefer **System managed size** on the drive where Windows is installed, then restart Windows.
4. Ensure the project is built with a 64-bit JDK 21 (`mvn -version` should report Java 21 and a 64-bit VM).

The batch file only adjusts Maven's JVM memory settings; it does not modify plugin source code.


## Fix: `release version 21 not supported`
This error means Maven is running with an older JDK. Paper 1.21.11 requires Java 21. Install a 64-bit **JDK 21**, then reopen CMD and check:

```bat
javac -version
mvn -version
```

Both the compiler and Maven must use Java 21 or newer. If multiple Java versions are installed, set `JAVA_HOME` to the JDK 21 installation folder and put `%JAVA_HOME%\bin` before older Java paths in `PATH`. Then run `build-low-memory.bat`. Do not lower `maven.compiler.release` to 17; it is not a valid fix for Paper 1.21.11.
