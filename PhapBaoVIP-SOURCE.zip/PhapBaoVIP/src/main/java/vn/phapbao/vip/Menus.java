package vn.phapbao.vip;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import vn.phapbao.vip.Model.PhapBao;
import vn.phapbao.vip.Model.Quality;
import vn.phapbao.vip.Model.Skill;
import vn.phapbao.vip.Model.Tier;

import java.util.ArrayList;
import java.util.List;

/** Full GUI navigation for PhapBaoVIP. */
public final class Menus implements Listener {
    public enum Kind { MAIN, CATALOG, SKILLS, UPGRADE, DETAIL }

    public static final class Holder implements InventoryHolder {
        private final Kind kind;
        private Inventory inv;
        Holder(Kind kind) { this.kind = kind; }
        @Override public Inventory getInventory() { return inv; }
    }

    private final PhapBaoVIP plugin;
    public Menus(PhapBaoVIP plugin) { this.plugin = plugin; }

    public void openMain(Player p) {
        Holder h = new Holder(Kind.MAIN);
        Inventory inv = Bukkit.createInventory(h, 54, Msg.c("&6&l⚔ PHÁP BẢO VIP ⚔"));
        h.inv = inv;
        fill(inv, Material.BLACK_STAINED_GLASS_PANE);
        Tier t = plugin.defs().tierOf(p);
        int used = plugin.players().bound(p.getUniqueId());

        inv.setItem(4, icon(Material.NETHER_STAR, "&e&lThông tin tu sĩ",
                "&7VIP: " + t.display(),
                "&7Linh lực: &b" + Msg.fmt(plugin.players().mana(p)) + "&7/&b" + Msg.fmt(plugin.players().maxMana(p)),
                "&7Bản mệnh: &f" + used + "&7/&f" + t.bindSlots(),
                "&7Giảm hồi chiêu: &a" + Msg.fmt(t.cooldownReduction()) + "%"));

        inv.setItem(10, icon(Material.ENCHANTING_TABLE, "&d&lLuyện hóa",
                "&7Cầm pháp bảo trên tay rồi bấm.", "&aLuyện hóa / nhận chủ"));
        inv.setItem(11, icon(Material.ANVIL, "&a&lCường hóa",
                "&7Nâng pháp bảo &e+0 → +50", "&7Damage skill tăng theo cấp."));
        inv.setItem(12, icon(Material.CHEST, "&b&lKho pháp bảo",
                "&7Xem toàn bộ pháp bảo đang có trong hệ thống."));
        inv.setItem(13, icon(Material.BOOK, "&d&lThư viện 50+ skill",
                "&7Xem tên, hệ và mô tả cơ chế skill."));
        inv.setItem(14, icon(Material.ENDER_EYE, "&5&lThông tin thức tỉnh",
                "&7Hệ thống thức tỉnh/Khí Linh/khảm ngọc", "&7được hiển thị tại đây khi module bật."));
        inv.setItem(15, icon(Material.AMETHYST_SHARD, "&5&lLinh lực",
                "&7Linh lực hiện tại: &b" + Msg.fmt(plugin.players().mana(p)),
                "&7Tự hồi theo VIP."));
        inv.setItem(16, icon(Material.ENCHANTED_BOOK, "&6&lThuộc tính pháp bảo",
                "&7Xem phẩm cấp, damage, skill và yêu cầu."));

        inv.setItem(19, icon(Material.REDSTONE, "&c&lGiải trừ",
                "&7Cầm pháp bảo đã nhận chủ rồi bấm."));
        boolean vip = t.vip() && t.dailyRolls() > 0;
        boolean claimed = plugin.actions().dailyClaimed(p);
        inv.setItem(20, icon(vip ? Material.ENDER_CHEST : Material.CHEST, "&6&lQuà VIP hằng ngày",
                vip ? "&7Lượt hôm nay: &f" + t.dailyRolls() : "&cChỉ dành cho VIP",
                vip ? (claimed ? "&cĐã nhận hôm nay." : "&aBấm để nhận") : "&8Cần VIP"));
        inv.setItem(22, icon(Material.DIAMOND_SWORD, "&b&lDanh mục pháp bảo", "&7Xem tất cả kiếm và skill đang có."));
        inv.setItem(24, icon(Material.SPYGLASS, "&e&lPháp bảo đang cầm", "&7Mở thông tin chi tiết món đang cầm."));
        inv.setItem(31, icon(Material.NETHER_STAR, "&6&lCấp bậc sức mạnh",
                "&7Damage skill bắt đầu từ &c100", "&7và tăng theo phẩm cấp + cường hóa."));
        inv.setItem(40, icon(Material.BARRIER, "&cĐóng", "&7Đóng menu."));
        p.openInventory(inv);
    }

    public void openCatalog(Player p) {
        Holder h = new Holder(Kind.CATALOG);
        Inventory inv = Bukkit.createInventory(h, 54, Msg.c("&b&l⚔ KHO PHÁP BẢO ⚔"));
        h.inv = inv;
        int slot = 0;
        for (PhapBao def : plugin.defs().all()) {
            if (slot >= 45) break;
            inv.setItem(slot++, plugin.items().create(def, 0));
        }
        inv.setItem(49, icon(Material.ARROW, "&e« Quay lại"));
        p.openInventory(inv);
    }

    public void openSkills(Player p) {
        Holder h = new Holder(Kind.SKILLS);
        Inventory inv = Bukkit.createInventory(h, 54, Msg.c("&d&l⚡ THƯ VIỆN 50+ SKILL ⚡"));
        h.inv = inv;
        int slot = 0;
        for (String[] s : skillLibrary()) {
            if (slot >= 45) break;
            inv.setItem(slot++, icon(skillMaterial(s[1]), "&b" + s[0],
                    "&7Hệ: &f" + s[1], "&7Cơ chế: &f" + SkillEngine.describe(s[1]),
                    "&8Skill được dùng khi gán vào pháp bảo."));
        }
        inv.setItem(49, icon(Material.ARROW, "&e« Quay lại"));
        p.openInventory(inv);
    }

    public void openDetail(Player p) {
        ItemStack held = p.getInventory().getItemInMainHand();
        PhapBao def = plugin.items().read(held);
        if (def == null) { plugin.send(p, "&cHãy cầm pháp bảo trên tay."); return; }
        Holder h = new Holder(Kind.DETAIL);
        Inventory inv = Bukkit.createInventory(h, 45, Msg.c("&6&l✦ CHI TIẾT PHÁP BẢO ✦"));
        h.inv = inv;
        Quality q = plugin.defs().quality(def.quality());
        int lv = plugin.items().level(held);
        double base = q == null ? 100 : q.skillDamageBase();
        double dmg = Math.max(100, base) * (1 + lv * plugin.getConfig().getDouble("settings.level-damage-scale", .10));
        inv.setItem(13, plugin.items().create(def, lv));
        inv.setItem(20, icon(Material.REDSTONE, "&c&lDamage skill",
                "&7Mốc phẩm cấp: &c" + Msg.fmt(base), "&7Sau +" + lv + ": &c" + Msg.fmt(dmg), "&7Cảnh giới sẽ cộng thêm theo config."));
        inv.setItem(22, icon(Material.ENCHANTED_BOOK, "&d&lSkill 1", skillLore(def.skill1())));
        inv.setItem(24, icon(Material.ENCHANTED_BOOK, "&d&lSkill 2", skillLore(def.skill2())));
        inv.setItem(40, icon(Material.ARROW, "&e« Quay lại"));
        p.openInventory(inv);
    }

    private String[] skillLore(Skill s) {
        if (s == null) return new String[]{"&8Không có"};
        return new String[]{"&f" + s.name(), "&7Hệ: &f" + s.type(), "&7Linh lực: &b" + Msg.fmt(s.mana()), "&7Hồi chiêu: &e" + Msg.fmt(s.cooldown()) + "s", "&7Hệ số: &c" + Msg.fmt(s.damageMultiplier()) + "x"};
    }

    private String[][] skillLibrary() {
        return new String[][]{
                {"Vạn Kiếm Quy Tông","VAN_KIEM_QUY_TONG"},{"Nhất Kiếm Phá Thiên","NHAT_KIEM_PHA_THIEN"},
                {"Kiếm Ảnh Phân Thân","KIEM_ANH_PHAN_THAN"},{"Kiếm Vực","KIEM_VUC"},{"Kiếm Bộ Vô Hình","KIEM_BO_VO_HINH"},
                {"Thiên Ngoại Phi Tiên","THIEN_NGOAI_PHI_TIEN"},{"Kiếm Tỏa Càn Khôn","KIEM_TOA_CAN_KHON"},{"Kiếm Ý Bạo Phát","KIEM_Y_BAO_PHAT"},
                {"Cửu Thiên Thần Lôi","CUU_THIEN_THAN_LOI"},{"Lôi Long Xuất Hải","LOI_LONG_XUAT_HAI"},{"Lôi Độn","LOI_DON"},{"Lôi Vực","LOI_VUC"},{"Thiên Lôi Phạt Thế","THIEN_LOI_PHAT_THE"},{"Lôi Thần Hộ Thể","LOI_THAN_HO_THE"},
                {"Tam Muội Chân Hỏa","TAM_MUOI_CHAN_HOA"},{"Hỏa Liên Bạo","HOA_LIEN_BAO"},{"Hỏa Long Thôn Thiên","HOA_LONG_THON_THIEN"},{"Phần Thiên","PHAN_THIEN"},{"Phượng Hoàng Niết Bàn","PHOENIX_NIET_BAN"},{"Hỏa Vực","HOA_VUC"},
                {"Vạn Lý Băng Phong","VAN_LY_BANG_PHONG"},{"Băng Long","BANG_LONG"},{"Hàn Nguyệt Trảm","HAN_NGUYET_TRAM"},{"Tuyệt Đối Băng Phong","TUYET_DOI_BANG_PHONG"},{"Băng Tường","BANG_TUONG"},{"Băng Vực","BANG_VUC"},
                {"Sinh Tử Luân Hồi","SINH_TU_LUAN_HOI"},{"Sinh Mệnh Chuyển Hoán","SINH_MENH_CHUYEN_HOAN"},{"Tử Vong Chỉ","TU_VONG_CHI"},{"Âm Dương Nghịch Chuyển","AM_DUONG_NGHICH_CHUYEN"},{"Luân Hồi Ấn","LUAN_HOI_AN"},{"Hoàng Tuyền Dẫn","HOANG_TUYEN_DAN"},
                {"Xuyên Không","XUYEN_KHONG"},{"Không Gian Trảm","KHONG_GIAN_TRAM"},{"Thuấn Bộ","THUAN_BO"},{"Hư Không Lao","HU_KHONG_LAO"},{"Thời Gian Tĩnh Chỉ","THOI_GIAN_TINH_CHI"},{"Thời Quang Hồi Tố","THOI_QUANG_HOI_TU"},
                {"Nhiếp Hồn","NHIEM_HON"},{"Soul Shatter","SOUL_SHATTER"},{"Thần Thức Áp Chế","THAN_THUC_AP_CHE"},{"Đoạt Hồn","DOAT_HON"},{"Vạn Hồn Phiên","VAN_HON_PHIEN"},
                {"Chu Thiên Tinh Đấu Trận","CHU_THIEN_TINH_DAU_TRAN"},{"Phong Thiên Tỏa Địa","PHONG_THIEN_TOA_DIA"},{"Cửu Cung Kiếm Trận","CUU_CUNG_KIEM_TRAN"},{"Diệt Thế Đại Trận","DIET_THE_DAI_TRAN"},{"Cấm Chế Phản Kích","CAM_CHE_PHAN_KICH"},{"Đạo Vực Giáng Lâm","DAO_VUC_GIANG_LAM"},{"Một Bước Đạp Thiên","MOT_BUOC_DAP_THIEN"}
        };
    }

    private Material skillMaterial(String type) {
        if (type.contains("LOI")) return Material.LIGHTNING_ROD;
        if (type.contains("HOA") || type.contains("PHAN_THIEN")) return Material.BLAZE_POWDER;
        if (type.contains("BANG")) return Material.PACKED_ICE;
        if (type.contains("KIEM")) return Material.DIAMOND_SWORD;
        if (type.contains("HON") || type.contains("THAN_THUC")) return Material.SOUL_LANTERN;
        if (type.contains("TRAN") || type.contains("CHE")) return Material.ENCHANTING_TABLE;
        return Material.NETHER_STAR;
    }

    @EventHandler public void onClick(InventoryClickEvent e) {
        if (!(e.getView().getTopInventory().getHolder() instanceof Holder h)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (e.getClickedInventory() == null || !e.getClickedInventory().equals(e.getView().getTopInventory())) return;
        int s = e.getSlot();
        switch (h.kind) {
            case MAIN -> {
                switch (s) {
                    case 10 -> plugin.actions().bind(p);
                    case 11 -> plugin.actions().upgrade(p);
                    case 12, 22 -> { Bukkit.getScheduler().runTask(plugin, () -> openCatalog(p)); return; }
                    case 13 -> { Bukkit.getScheduler().runTask(plugin, () -> openSkills(p)); return; }
                    case 14, 15, 16, 31 -> plugin.send(p, "&eModule hiển thị đang sẵn sàng; tính năng nâng cao sẽ dùng config/module tương ứng.");
                    case 19 -> plugin.actions().unbind(p);
                    case 20 -> plugin.actions().daily(p);
                    case 24 -> { Bukkit.getScheduler().runTask(plugin, () -> openDetail(p)); return; }
                    case 40 -> { p.closeInventory(); return; }
                    default -> { return; }
                }
                Bukkit.getScheduler().runTask(plugin, () -> { if (p.isOnline()) openMain(p); });
            }
            case CATALOG -> {
                if (s == 49) { Bukkit.getScheduler().runTask(plugin, () -> openMain(p)); return; }
                PhapBao def = plugin.items().read(e.getCurrentItem());
                if (def != null && p.hasPermission("phapbao.admin")) { plugin.actions().give(p, plugin.items().create(def, 0)); plugin.send(p, "&aĐã nhận &f" + def.name() + "&a."); }
            }
            case SKILLS -> { if (s == 49) Bukkit.getScheduler().runTask(plugin, () -> openMain(p)); }
            case DETAIL -> { if (s == 40) Bukkit.getScheduler().runTask(plugin, () -> openMain(p)); }
            case UPGRADE -> { }
        }
    }

    @EventHandler public void onDrag(InventoryDragEvent e) { if (e.getView().getTopInventory().getHolder() instanceof Holder) e.setCancelled(true); }

    private void fill(Inventory inv, Material m) { ItemStack f = icon(m, " "); for (int i=0;i<inv.getSize();i++) inv.setItem(i,f); }
    private ItemStack icon(Material m, String name, String... lore) {
        ItemStack it = new ItemStack(m); ItemMeta meta = it.getItemMeta(); meta.displayName(Msg.c(name));
        List<Component> l = new ArrayList<>(); for (String s:lore) l.add(Msg.c(s)); meta.lore(l); meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES); it.setItemMeta(meta); return it;
    }
}
