package vn.phapbao.vip;

import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.MemoryConfiguration;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import vn.phapbao.vip.Model.PhapBao;
import vn.phapbao.vip.Model.Quality;
import vn.phapbao.vip.Model.Skill;
import vn.phapbao.vip.Model.Tier;

import java.util.*;

/** Doc phap bao, pham cap, bac VIP tu config. */
public final class Defs {
    private final PhapBaoVIP plugin;
    private final Map<String, Quality> qualities = new LinkedHashMap<>();
    private final Map<String, PhapBao> items = new LinkedHashMap<>();
    private final List<Tier> tiers = new ArrayList<>(); // cao -> thap
    private Tier defaultTier;
    private final Random rnd = new Random();

    public Defs(PhapBaoVIP plugin) {
        this.plugin = plugin;
    }

    public void load() {
        FileConfiguration cfg = plugin.getConfig();
        qualities.clear();
        items.clear();
        tiers.clear();

        ConfigurationSection qs = cfg.getConfigurationSection("quality");
        if (qs != null) {
            for (String id : qs.getKeys(false)) {
                ConfigurationSection q = qs.getConfigurationSection(id);
                if (q == null) continue;
                double baseDamage = q.getDouble("skill-damage", defaultQualityDamage(id));
                qualities.put(id, new Quality(id, q.getString("name", id), q.getString("color", "&f"),
                        q.getInt("weight", 10), q.getBoolean("glow", false), baseDamage));
            }
        }

        ConfigurationSection ps = cfg.getConfigurationSection("phapbao");
        if (ps != null) {
            for (String id : ps.getKeys(false)) {
                ConfigurationSection s = ps.getConfigurationSection(id);
                if (s == null) continue;
                String mat = s.getString("material", "IRON_SWORD");
                if (Material.matchMaterial(mat) == null) {
                    plugin.getLogger().warning("Phap bao '" + id + "': material '" + mat + "' khong hop le, dung IRON_SWORD.");
                    mat = "IRON_SWORD";
                }
                Skill s1 = Skill.read(s.getConfigurationSection("skill1"));
                if (s1 == null) s1 = Skill.read(new MemoryConfiguration());
                Skill s2 = Skill.read(s.getConfigurationSection("skill2"));
                items.put(id, new PhapBao(id, s.getString("name", id), s.getString("quality", "ha-pham"), mat,
                        s.getBoolean("vip-only", false), s.getInt("min-realm", 0),
                        s.getDouble("attack-damage", 8), s.getDouble("attack-speed", 1.6),
                        s.getStringList("lore"), s1, s2));
            }
        }

        defaultTier = readTier("default", cfg.getConfigurationSection("vip.default"), false);
        ConfigurationSection ts = cfg.getConfigurationSection("vip.tiers");
        if (ts != null) {
            for (String id : ts.getKeys(false)) {
                ConfigurationSection t = ts.getConfigurationSection(id);
                if (t != null) tiers.add(readTier(id, t, true));
            }
        }
        Collections.reverse(tiers); // khai bao thap -> cao, dao lai de kiem tra bac cao truoc
        plugin.getLogger().info("Da nap " + items.size() + " phap bao, " + tiers.size() + " bac VIP.");
    }

    private double defaultQualityDamage(String id) {
        return switch (id.toLowerCase(Locale.ROOT)) {
            case "ha-pham" -> 100.0;
            case "trung-pham" -> 150.0;
            case "thuong-pham" -> 250.0;
            case "cuc-pham" -> 400.0;
            case "tien-khi" -> 1000.0;
            case "thanh-khi" -> 1500.0;
            case "de-khi" -> 2500.0;
            case "than-khi" -> 4000.0;
            case "hong-mong" -> 7000.0;
            default -> 100.0;
        };
    }

    private Tier readTier(String id, ConfigurationSection t, boolean vip) {
        if (t == null) t = new MemoryConfiguration();
        return new Tier(id, t.getString("display", "&7Phàm Nhân"), t.getString("permission", ""),
                t.getInt("bind-slots", 1), t.getDouble("cooldown-reduction", 0),
                t.getDouble("mana-bonus", 0), t.getDouble("regen-multiplier", 1.0),
                t.getDouble("upgrade-bonus", 0), t.getDouble("fail-refund", 0),
                t.getInt("daily-rolls", 0), vip);
    }

    public Tier tierOf(Player p) {
        for (Tier t : tiers) {
            if (!t.permission().isEmpty() && p.hasPermission(t.permission())) return t;
        }
        return defaultTier;
    }

    public PhapBao get(String id) {
        return id == null ? null : items.get(id);
    }

    public Collection<PhapBao> all() {
        return items.values();
    }

    public Quality quality(String id) {
        return qualities.get(id);
    }

    /** Boc ngau nhien theo trong so pham cap. */
    public PhapBao random(boolean includeVip) {
        Map<String, List<PhapBao>> byQuality = new HashMap<>();
        for (PhapBao d : items.values()) {
            if (d.vipOnly() && !includeVip) continue;
            byQuality.computeIfAbsent(d.quality(), k -> new ArrayList<>()).add(d);
        }
        int total = 0;
        for (String q : byQuality.keySet()) total += weight(q);
        if (total <= 0) return null;
        int roll = rnd.nextInt(total);
        for (Map.Entry<String, List<PhapBao>> e : byQuality.entrySet()) {
            int w = weight(e.getKey());
            if (roll < w) {
                List<PhapBao> list = e.getValue();
                return list.get(rnd.nextInt(list.size()));
            }
            roll -= w;
        }
        return null;
    }

    private int weight(String qualityId) {
        Quality q = qualities.get(qualityId);
        return q == null ? 10 : Math.max(1, q.weight());
    }
}
