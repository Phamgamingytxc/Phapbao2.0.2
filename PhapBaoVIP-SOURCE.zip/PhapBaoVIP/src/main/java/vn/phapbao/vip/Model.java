package vn.phapbao.vip;

import org.bukkit.configuration.ConfigurationSection;

import java.util.List;
import java.util.Locale;

/** Cac record du lieu doc tu config.yml. */
public final class Model {
    private Model() {}

    public record Quality(String id, String name, String color, int weight, boolean glow, double skillDamageBase) {}

    public record Skill(String name, String type, double mana, double cooldown, double damage,
                        double radius, double range, double duration, int count, double power,
                        String particle, String particle2, String color) {
        /** Hệ số riêng cho 50+ skill mới; mặc định giữ damage của skill cơ bản. */
        public double damageMultiplier() {
            return switch (type) {
                case "VAN_KIEM_QUY_TONG", "NHAT_KIEM_PHA_THIEN", "THIEN_NGOAI_PHI_TIEN", "DIET_THE_DAI_TRAN", "MOT_BUOC_DAP_THIEN" -> 3.0;
                case "KIEM_ANH_PHAN_THAN", "KIEM_VUC", "CUU_CUNG_KIEM_TRAN", "LUOI_TU_TUYET_DIA", "DAO_VUC_GIANG_LAM" -> 2.0;
                case "PHOENIX_NIET_BAN", "LUAN_HOI_AN", "THOI_QUANG_HOI_TU", "HOI_MENH" -> 1.5;
                default -> 1.0;
            };
        }

        static Skill read(ConfigurationSection s) {
            if (s == null) return null;
            return new Skill(
                    s.getString("name", "Chiêu Thức"),
                    s.getString("type", "KIEM_KHI").toUpperCase(Locale.ROOT),
                    s.getDouble("mana", 20),
                    s.getDouble("cooldown", 8),
                    s.getDouble("damage", 8),
                    s.getDouble("radius", 4),
                    s.getDouble("range", 12),
                    s.getDouble("duration", 3),
                    s.getInt("count", 3),
                    s.getDouble("power", 1),
                    s.getString("particle", "END_ROD"),
                    s.getString("particle2", "CRIT"),
                    s.getString("color", "FFFFFF"));
        }
    }

    public record PhapBao(String id, String name, String quality, String material, boolean vipOnly,
                          int minRealm, double attackDamage, double attackSpeed, List<String> lore,
                          Skill skill1, Skill skill2) {}

    public record Tier(String id, String display, String permission, int bindSlots,
                       double cooldownReduction, double manaBonus, double regenMultiplier,
                       double upgradeBonus, double failRefund, int dailyRolls, boolean vip) {}
}
