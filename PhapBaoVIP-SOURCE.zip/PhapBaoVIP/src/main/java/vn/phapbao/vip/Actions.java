package vn.phapbao.vip;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import vn.phapbao.vip.Model.PhapBao;
import vn.phapbao.vip.Model.Tier;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

/** Cac hanh dong dung chung cho lenh va GUI. */
public final class Actions {
    private final PhapBaoVIP plugin;

    public Actions(PhapBaoVIP plugin) {
        this.plugin = plugin;
    }

    private void fail(Player p, String msg) {
        plugin.send(p, "&c" + msg);
        p.playSound(p.getLocation(), Sound.BLOCK_ANVIL_LAND, 0.5f, 1.2f);
    }

    private void ok(Player p, String msg) {
        plugin.send(p, "&a" + msg);
    }

    // ---------- Luyen hoa ----------
    public void bind(Player p) {
        ItemStack it = p.getInventory().getItemInMainHand();
        PhapBao def = plugin.items().read(it);
        if (def == null) {
            fail(p, "Hãy cầm pháp bảo trên tay.");
            return;
        }
        UUID owner = plugin.items().owner(it);
        if (owner != null) {
            fail(p, owner.equals(p.getUniqueId()) ? "Pháp bảo này đã được ngươi luyện hóa rồi." : "Pháp bảo này đã có chủ.");
            return;
        }
        Tier t = plugin.defs().tierOf(p);
        if (def.vipOnly() && !t.vip()) {
            fail(p, "Pháp bảo này chỉ dành cho VIP.");
            return;
        }
        if (plugin.players().realm(p) < def.minRealm()) {
            fail(p, "Cảnh giới chưa đủ, cần cảnh giới " + def.minRealm() + " để luyện hóa.");
            return;
        }
        int used = plugin.players().bound(p.getUniqueId());
        if (used >= t.bindSlots()) {
            fail(p, "Đã đạt giới hạn bản mệnh pháp bảo (" + used + "/" + t.bindSlots() + "). Giải trừ một món hoặc nâng VIP để mở thêm.");
            return;
        }
        plugin.players().addBound(p.getUniqueId(), 1);
        plugin.items().render(it, def, plugin.items().level(it), p.getUniqueId(), p.getName());
        p.getInventory().setItemInMainHand(it);
        ok(p, "Luyện hóa thành công! " + def.name() + " đã nhận ngươi làm chủ. (" + (used + 1) + "/" + t.bindSlots() + ")");
        p.playSound(p.getLocation(), Sound.BLOCK_ENCHANTMENT_TABLE_USE, 1f, 1.2f);
        plugin.engine().fx(p.getLocation().add(0, 1, 0), "ENCHANT", 60, 0.6, 0.8, 0.6, 0.5, "FFFFFF");
    }

    // ---------- Giai tru ----------
    public void unbind(Player p) {
        ItemStack it = p.getInventory().getItemInMainHand();
        PhapBao def = plugin.items().read(it);
        if (def == null) {
            fail(p, "Hãy cầm pháp bảo trên tay.");
            return;
        }
        UUID owner = plugin.items().owner(it);
        if (owner == null || !owner.equals(p.getUniqueId())) {
            fail(p, "Pháp bảo này không phải của ngươi.");
            return;
        }
        plugin.items().render(it, def, plugin.items().level(it), null, null);
        p.getInventory().setItemInMainHand(it);
        plugin.players().addBound(p.getUniqueId(), -1);
        ok(p, "Đã giải trừ liên kết với " + def.name() + ". Món này có thể trao cho người khác.");
        p.playSound(p.getLocation(), Sound.BLOCK_BEACON_DEACTIVATE, 1f, 1.2f);
    }

    // ---------- Nang cap ----------
    public int upgradeCost(int level) {
        FileConfiguration c = plugin.getConfig();
        return c.getInt("upgrade.base-amount", 8) + c.getInt("upgrade.per-level", 6) * level;
    }

    public double upgradeRate(Player p, int level) {
        FileConfiguration c = plugin.getConfig();
        double rate = c.getDouble("upgrade.rate-start", 100)
                - c.getDouble("upgrade.rate-drop-per-level", 9) * level
                + plugin.defs().tierOf(p).upgradeBonus();
        return Math.max(c.getDouble("upgrade.min-rate", 15), Math.min(100, rate));
    }

    public void upgrade(Player p) {
        FileConfiguration cfg = plugin.getConfig();
        ItemStack it = p.getInventory().getItemInMainHand();
        PhapBao def = plugin.items().read(it);
        if (def == null) {
            fail(p, "Hãy cầm pháp bảo trên tay.");
            return;
        }
        UUID owner = plugin.items().owner(it);
        if (owner == null || !owner.equals(p.getUniqueId())) {
            fail(p, "Chỉ chủ nhân (đã luyện hóa) mới có thể nâng cấp pháp bảo.");
            return;
        }
        int level = plugin.items().level(it);
        int max = cfg.getInt("settings.max-level", 10);
        if (level >= max) {
            fail(p, "Pháp bảo đã đạt cấp luyện tối đa (+" + max + ").");
            return;
        }
        Material mat = Material.matchMaterial(cfg.getString("upgrade.material", "AMETHYST_SHARD"));
        if (mat == null) {
            fail(p, "Cấu hình upgrade.material không hợp lệ, hãy báo admin.");
            return;
        }
        String matName = cfg.getString("upgrade.material-name", "Linh Thạch");
        int cost = upgradeCost(level);
        int have = count(p, mat);
        if (have < cost) {
            fail(p, "Thiếu nguyên liệu: cần " + cost + " " + matName + " (đang có " + have + ").");
            return;
        }
        take(p, mat, cost);
        double rate = upgradeRate(p, level);
        if (ThreadLocalRandom.current().nextDouble() * 100.0 < rate) {
            int next = level + 1;
            plugin.items().render(it, def, next, p.getUniqueId(), p.getName());
            p.getInventory().setItemInMainHand(it);
            ok(p, "Nâng cấp thành công! " + def.name() + " lên +" + next + ".");
            p.playSound(p.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1f, 1.1f);
            plugin.engine().fx(p.getLocation().add(0, 1, 0), "TOTEM_OF_UNDYING", 50, 0.5, 0.9, 0.5, 0.4, "FFFFFF");
            if (next >= cfg.getInt("upgrade.broadcast-level", 8)) {
                Bukkit.broadcast(Msg.c(cfg.getString("settings.prefix", "") + "&e" + p.getName()
                        + " &7vừa luyện &f" + def.name() + " &7lên &e+" + next + "&7!"));
            }
        } else {
            Tier t = plugin.defs().tierOf(p);
            int refund = (int) Math.floor(cost * t.failRefund() / 100.0);
            if (refund > 0) give(p, new ItemStack(mat, refund));
            fail(p, "Nâng cấp thất bại, nguyên liệu tan biến" + (refund > 0 ? " (VIP hoàn lại " + refund + " " + matName + ")" : "") + ".");
        }
    }

    // ---------- Qua VIP hang ngay ----------
    public void daily(Player p) {
        Tier t = plugin.defs().tierOf(p);
        if (!t.vip() || t.dailyRolls() <= 0) {
            fail(p, "Quà hằng ngày chỉ dành cho VIP.");
            return;
        }
        String today = LocalDate.now().toString();
        if (today.equals(plugin.players().lastDaily(p.getUniqueId()))) {
            fail(p, "Hôm nay ngươi đã nhận quà rồi, mai quay lại nhé.");
            return;
        }
        int level = plugin.getConfig().getInt("daily.level", 0);
        List<String> names = new ArrayList<>();
        for (int i = 0; i < t.dailyRolls(); i++) {
            PhapBao def = plugin.defs().random(true);
            if (def == null) continue;
            give(p, plugin.items().create(def, level));
            names.add(def.name());
        }
        if (names.isEmpty()) {
            fail(p, "Chưa có pháp bảo nào để tặng, hãy báo admin.");
            return;
        }
        plugin.players().setDaily(p.getUniqueId(), today);
        ok(p, "Nhận quà " + t.display() + "&a: &f" + String.join("&7, &f", names));
        p.playSound(p.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1f, 1.4f);
    }

    public boolean dailyClaimed(Player p) {
        return LocalDate.now().toString().equals(plugin.players().lastDaily(p.getUniqueId()));
    }

    // ---------- Kho do ----------
    public void give(Player p, ItemStack stack) {
        for (ItemStack left : p.getInventory().addItem(stack).values()) {
            p.getWorld().dropItemNaturally(p.getLocation(), left);
        }
    }

    public int count(Player p, Material mat) {
        int n = 0;
        for (ItemStack s : p.getInventory().getStorageContents()) {
            if (s != null && s.getType() == mat && plugin.items().read(s) == null) n += s.getAmount();
        }
        return n;
    }

    private void take(Player p, Material mat, int amount) {
        int left = amount;
        ItemStack[] cs = p.getInventory().getStorageContents();
        for (int i = 0; i < cs.length && left > 0; i++) {
            ItemStack s = cs[i];
            if (s == null || s.getType() != mat || plugin.items().read(s) != null) continue;
            int t = Math.min(left, s.getAmount());
            if (t == s.getAmount()) cs[i] = null;
            else s.setAmount(s.getAmount() - t);
            left -= t;
        }
        p.getInventory().setStorageContents(cs);
    }
}
