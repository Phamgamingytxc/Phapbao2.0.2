@echo off
setlocal
title Build PhapBaoVIP - Java 21
cd /d "%~dp0"

echo =============================================
echo PhapBaoVIP - build for Paper 1.21.11
echo =============================================
echo.
echo [1/4] Checking Java compiler...
where javac >nul 2>nul
if errorlevel 1 (
  echo ERROR: javac not found. Install a 64-bit JDK 21, not just a JRE.
  goto :fail
)
for /f "tokens=2 delims=\" " %%V in ('javac -version 2^>^&1') do set JAVAVER=%%V
echo javac version: %JAVAVER%
for /f "tokens=1 delims=." %%M in ("%JAVAVER%") do set JAVAMAJOR=%%M
if not defined JAVAMAJOR goto :badjava
if %JAVAMAJOR% LSS 21 goto :badjava

echo.
echo [2/4] Checking Maven Java runtime...
mvn -version
if errorlevel 1 (
  echo ERROR: Maven failed. Check JAVA_HOME and PATH.
  goto :fail
)
for /f "tokens=3" %%V in ('mvn -version ^| findstr /C:"Java version"') do set MVNJAVA=%%V
if not defined MVNJAVA (
  echo WARNING: Could not parse Maven Java version. Verify the Java version shown above is 21+.
)

echo.
echo [3/4] Setting conservative memory options...
set "MAVEN_OPTS=-Xms128m -Xmx512m -XX:MaxMetaspaceSize=192m"

echo.
echo [4/4] Building plugin...
call mvn clean package
if errorlevel 1 (
  echo.
  echo BUILD FAILED. Copy the first [ERROR] lines when asking for help.
  goto :fail
)
echo.
echo BUILD SUCCESS. JAR: target\PhapBaoVIP-1.0.0.jar
pause
exit /b 0

:badjava
echo ERROR: Java 21 or newer is required. Your javac is %JAVAVER%.
echo Install JDK 21 from https://adoptium.net/temurin/releases/?version=21
 echo Then set JAVA_HOME to the JDK folder and add %%JAVA_HOME%%\bin to PATH.
goto :fail

:fail
echo.
echo Fix Java first, then reopen CMD and run this file again.
pause
exit /b 1
